
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import AITutor from './components/AITutor';
import Quiz from './components/Quiz';
import Courses from './components/Courses';
import Community from './components/Community';
import LiveLab from './components/LiveLab';
import VoiceTeacher from './components/VoiceTeacher';
import OnlineClass from './components/OnlineClass';
import { AppView, UserProgress, Lesson, CourseModule } from './types';
import { Bell, Search, Settings, WifiOff } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [tutorContext, setTutorContext] = useState<Lesson | null>(null);
  const [activeModule, setActiveModule] = useState<CourseModule | null>(null);
  
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('lingua_progress');
    return saved ? JSON.parse(saved) : {
      level: 12,
      xp: 4250,
      badges: ['Early Bird', 'AI Partner'],
      streak: 4,
      completedLessons: ['1', '2']
    };
  });

  useEffect(() => {
    localStorage.setItem('lingua_progress', JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleStartTutor = (course: Lesson) => {
    setTutorContext(course);
    setCurrentView(AppView.AI_TUTOR);
  };

  const handleStartOnlineClass = (course: Lesson, module: CourseModule) => {
    setTutorContext(course);
    setActiveModule(module);
    setCurrentView(AppView.ONLINE_CLASS);
  };

  const handleUpdateXP = (amount: number) => {
    setProgress(prev => {
      const newXP = prev.xp + amount;
      const newLevel = Math.floor(newXP / 500) + 1;
      return { ...prev, xp: newXP, level: newLevel };
    });
  };

  const renderView = () => {
    switch (currentView) {
      case AppView.DASHBOARD:
        return <Dashboard progress={progress} />;
      case AppView.COURSES:
        return (
          <Courses 
            onStartTutor={handleStartTutor} 
            onStartOnlineClass={handleStartOnlineClass}
          />
        );
      case AppView.AI_TUTOR:
        return <AITutor initialContext={tutorContext} />;
      case AppView.LIVE_LAB:
        return <LiveLab />;
      case AppView.VOICE_TEACHER:
        return <VoiceTeacher />;
      case AppView.ONLINE_CLASS:
        if (tutorContext && activeModule) {
          return (
            <OnlineClass 
              course={tutorContext} 
              module={activeModule} 
              onBack={() => setCurrentView(AppView.COURSES)}
              onUpdateXP={handleUpdateXP}
            />
          );
        }
        return <Courses onStartTutor={handleStartTutor} onStartOnlineClass={handleStartOnlineClass} />;
      case AppView.QUIZ:
        return <Quiz />;
      case AppView.COMMUNITY:
        return <Community />;
      default:
        return (
          <div className="text-center py-20">
            <h2 className="text-3xl font-bold text-slate-800 capitalize">{currentView.replace('_', ' ')}</h2>
            <p className="text-slate-500 mt-4">This section is currently under development.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar currentView={currentView} onViewChange={(view) => {
        if (view !== AppView.AI_TUTOR && view !== AppView.ONLINE_CLASS) {
          setTutorContext(null);
          setActiveModule(null);
        }
        setCurrentView(view);
      }} />

      <main className="flex-grow md:ml-64 transition-all duration-300">
        <nav className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-6 flex-grow">
            <div className="relative w-full max-w-md hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Search lessons..."
                className="w-full bg-slate-50 border-none rounded-full py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              />
            </div>
            {isOffline && (
              <div className="flex items-center gap-2 px-3 py-1 bg-amber-50 text-amber-600 rounded-full text-xs font-bold animate-pulse">
                <WifiOff size={14} /> Offline Mode
              </div>
            )}
          </div>

          <div className="flex items-center gap-4 ml-auto">
            <button className="p-2 text-slate-400 hover:text-indigo-600 transition-colors">
              <Bell size={20} />
            </button>
            <button className="p-2 text-slate-400 hover:text-indigo-600 transition-colors">
              <Settings size={20} />
            </button>
            <div className="h-8 w-[1px] bg-slate-200 mx-2"></div>
            <div className="flex items-center gap-3 cursor-pointer hover:opacity-80 transition-opacity">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-800 leading-none">Alex Johnson</p>
                <p className="text-[10px] text-slate-500 font-medium">Level {progress.level} • {progress.streak} Day Streak</p>
              </div>
              <img 
                src="https://picsum.photos/id/64/100/100" 
                alt="Profile" 
                className="w-10 h-10 rounded-full border-2 border-white shadow-sm ring-1 ring-slate-100"
              />
            </div>
          </div>
        </nav>

        <div className="p-8 max-w-7xl mx-auto">
          {renderView()}
        </div>
      </main>

      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-md md:hidden glass-morphism rounded-full px-4 py-3 flex items-center justify-around shadow-2xl z-50 border border-white/50">
        {[
          { id: AppView.DASHBOARD, label: 'Home' },
          { id: AppView.COURSES, label: 'Learn' },
          { id: AppView.VOICE_TEACHER, label: 'Voice' },
          { id: AppView.COMMUNITY, label: 'Club' }
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            className={`flex flex-col items-center gap-1 transition-all ${
              currentView === item.id ? 'text-indigo-600 scale-110' : 'text-slate-400'
            }`}
          >
            <span className="text-[10px] font-bold">{item.label}</span>
            {currentView === item.id && <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></div>}
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;
