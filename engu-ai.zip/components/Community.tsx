
import React from 'react';
import { Users, MessageCircle, Heart, Share2 } from 'lucide-react';

const Community: React.FC = () => {
  const posts = [
    { id: 1, user: 'Sarah L.', avatar: 'https://i.pravatar.cc/150?u=sarah', content: "Just finished the Public Speaking course! Feeling so much more confident for my presentation tomorrow. 🎤", likes: 24, comments: 5 },
    { id: 2, user: 'Marco R.', avatar: 'https://i.pravatar.cc/150?u=marco', content: "Anyone want to join a study group for 'Business English'? Looking for 2-3 partners to practice with on the Voice Lab. 🚀", likes: 12, comments: 18 },
    { id: 3, user: 'Yuki T.', avatar: 'https://i.pravatar.cc/150?u=yuki', content: "Quick tip: Try using the Voice Lab's real-time feedback for shadow reading. It's a game changer! 🧠", likes: 45, comments: 3 },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-500">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
          <div className="flex gap-4">
            <img src="https://picsum.photos/id/64/100/100" className="w-10 h-10 rounded-full" alt="Me" />
            <input 
              type="text" 
              placeholder="Share your progress or ask a question..." 
              className="flex-grow bg-slate-50 border-none rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {posts.map(post => (
          <div key={post.id} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <img src={post.avatar} className="w-10 h-10 rounded-full" alt={post.user} />
              <div>
                <p className="font-bold text-slate-800 text-sm">{post.user}</p>
                <p className="text-[10px] text-slate-400">2 hours ago</p>
              </div>
            </div>
            <p className="text-slate-600 mb-6">{post.content}</p>
            <div className="flex items-center gap-6 pt-4 border-t border-slate-50">
              <button className="flex items-center gap-2 text-slate-400 hover:text-indigo-600 transition-colors text-xs font-medium">
                <Heart size={16} /> {post.likes}
              </button>
              <button className="flex items-center gap-2 text-slate-400 hover:text-indigo-600 transition-colors text-xs font-medium">
                <MessageCircle size={16} /> {post.comments}
              </button>
              <button className="flex items-center gap-2 text-slate-400 hover:text-indigo-600 transition-colors text-xs font-medium ml-auto">
                <Share2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-6">
        <div className="bg-indigo-600 rounded-3xl p-6 text-white">
          <h3 className="text-lg font-bold mb-4">Active Study Groups</h3>
          <div className="space-y-4">
            {[
              { name: 'IELTS Prep 2024', members: 124 },
              { name: 'Business Networking', members: 89 },
              { name: 'Daily News Chat', members: 456 },
            ].map((group, i) => (
              <div key={i} className="flex items-center justify-between bg-white/10 p-3 rounded-xl hover:bg-white/20 cursor-pointer transition-colors">
                <div>
                  <p className="text-sm font-bold">{group.name}</p>
                  <p className="text-[10px] opacity-70">{group.members} members online</p>
                </div>
                <Users size={16} />
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-3 bg-white text-indigo-600 rounded-xl font-bold text-sm">Create Group</button>
        </div>
      </div>
    </div>
  );
};

export default Community;
