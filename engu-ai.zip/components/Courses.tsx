
import React, { useState } from 'react';
import { COURSE_LIST } from '../constants';
import { BookOpen, Clock, Star, Play, ChevronLeft, MessageCircle, CheckCircle2, Monitor } from 'lucide-react';
import { Lesson, CourseModule } from '../types';

interface CoursesProps {
  onStartTutor: (course: Lesson) => void;
  onStartOnlineClass: (course: Lesson, module: CourseModule) => void;
}

const Courses: React.FC<CoursesProps> = ({ onStartTutor, onStartOnlineClass }) => {
  const [selectedCourse, setSelectedCourse] = useState<Lesson | null>(null);

  if (selectedCourse) {
    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500 pb-20">
        <button 
          onClick={() => setSelectedCourse(null)}
          className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 transition-colors font-medium"
        >
          <ChevronLeft size={20} /> Back to Catalog
        </button>

        <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-sm">
          <div className="flex flex-col md:flex-row justify-between items-start gap-6">
            <div className="space-y-4 max-w-2xl">
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-xs font-bold uppercase tracking-wider">
                  {selectedCourse.category}
                </span>
                <span className="text-slate-400 text-xs flex items-center gap-1">
                  <Star size={12} className="fill-yellow-400 text-yellow-400" /> {selectedCourse.difficulty}
                </span>
              </div>
              <h1 className="text-3xl font-bold text-slate-800">{selectedCourse.title}</h1>
              <p className="text-slate-600 leading-relaxed">{selectedCourse.description}</p>
            </div>
            
            <button 
              onClick={() => onStartTutor(selectedCourse)}
              className="flex items-center gap-3 px-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 shrink-0"
            >
              <MessageCircle size={20} />
              AI Chat Tutor
            </button>
          </div>

          <div className="mt-12 space-y-4">
            <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              <BookOpen size={20} className="text-indigo-600" /> Course Modules
            </h2>
            {selectedCourse.modules?.map((module, idx) => (
              <div key={module.id} className="group p-6 bg-slate-50 rounded-2xl border border-transparent hover:border-emerald-100 hover:bg-white transition-all">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                  <div className="flex items-center gap-5">
                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-slate-400 font-black border border-slate-100 group-hover:bg-emerald-600 group-hover:text-white transition-all group-hover:rotate-6 shadow-sm">
                      {idx + 1}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800 text-lg">{module.title}</h4>
                      <p className="text-sm text-slate-500 mt-1">{module.duration} • Absolute Basics</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => onStartOnlineClass(selectedCourse, module)}
                    className="px-8 py-3.5 bg-emerald-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-emerald-700 transition-all flex items-center gap-3 shadow-xl shadow-emerald-100 active:scale-95"
                  >
                    <Play size={18} fill="currentColor" /> Let's Start
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Learning Catalog</h1>
          <p className="text-slate-500 mt-1">Pick a course to start your virtual classroom experience.</p>
        </div>
        <div className="flex gap-2 p-1 bg-white border border-slate-200 rounded-xl overflow-hidden">
           <button className="px-4 py-1.5 text-xs font-bold bg-indigo-50 text-indigo-600 rounded-lg">All Courses</button>
           <button className="px-4 py-1.5 text-xs font-bold text-slate-500 hover:bg-slate-50 rounded-lg">Professional</button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-24">
        {COURSE_LIST.map((course) => (
          <div 
            key={course.id} 
            onClick={() => setSelectedCourse(course)}
            className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group cursor-pointer"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-xs font-bold uppercase tracking-wider">
                {course.category}
              </div>
              {course.isFree && (
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded flex items-center gap-1">
                  <CheckCircle2 size={10} /> FREE
                </span>
              )}
            </div>
            
            <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-indigo-600 transition-colors">
              {course.title}
            </h3>
            <p className="text-slate-500 text-sm mb-6 line-clamp-2">
              {course.description}
            </p>

            <div className="flex items-center gap-6 text-sm text-slate-400 mb-6">
              <div className="flex items-center gap-2">
                <Clock size={16} />
                <span>{course.duration}</span>
              </div>
              <div className="flex items-center gap-2">
                <Star size={16} className="text-yellow-400 fill-yellow-400" />
                <span className="text-slate-600 font-medium">{course.difficulty}</span>
              </div>
            </div>

            <button className="w-full flex items-center justify-center gap-2 py-3 bg-slate-50 group-hover:bg-indigo-600 group-hover:text-white text-slate-700 rounded-xl font-bold transition-all">
              <Play size={18} />
              Open Course
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Courses;
