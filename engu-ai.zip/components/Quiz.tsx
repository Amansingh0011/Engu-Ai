
import React, { useState, useEffect } from 'react';
import { generateQuiz } from '../services/geminiService';
import { QuizQuestion } from '../types';
import { CheckCircle2, XCircle, BrainCircuit, RefreshCcw } from 'lucide-react';

const Quiz: React.FC = () => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [completed, setCompleted] = useState(false);

  const startNewQuiz = async () => {
    setLoading(true);
    const newQuestions = await generateQuiz('Business English Idioms');
    setQuestions(newQuestions);
    setCurrentIndex(0);
    setScore(0);
    setSelectedOption(null);
    setShowExplanation(false);
    setCompleted(false);
    setLoading(false);
  };

  useEffect(() => {
    startNewQuiz();
  }, []);

  const handleSelect = (idx: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(idx);
    setShowExplanation(true);
    if (idx === questions[currentIndex].correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(c => c + 1);
      setSelectedOption(null);
      setShowExplanation(false);
    } else {
      setCompleted(true);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <BrainCircuit className="text-indigo-600 animate-pulse mb-4" size={48} />
        <p className="text-slate-500 font-medium">Generating a personalized quiz for you...</p>
      </div>
    );
  }

  if (completed) {
    return (
      <div className="bg-white p-12 rounded-3xl shadow-xl text-center max-w-xl mx-auto border border-slate-100 animate-in zoom-in-95 duration-500">
        <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <span className="text-4xl">🎉</span>
        </div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Quiz Completed!</h2>
        <p className="text-slate-500 mb-8">You scored {score} out of {questions.length}</p>
        
        <div className="bg-slate-50 rounded-2xl p-6 mb-8 text-left">
          <p className="text-sm font-bold text-slate-700 mb-4">Skill Assessment:</p>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-600 text-sm">Vocabulary</span>
              <span className="text-indigo-600 font-bold text-sm">85%</span>
            </div>
            <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-600 w-[85%]"></div>
            </div>
          </div>
        </div>

        <button 
          onClick={startNewQuiz}
          className="w-full flex items-center justify-center gap-2 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
        >
          <RefreshCcw size={20} />
          Try Another Topic
        </button>
      </div>
    );
  }

  const currentQ = questions[currentIndex];

  return (
    <div className="max-w-3xl mx-auto">
      {currentQ && (
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100 animate-in slide-in-from-right-4 duration-500">
          <div className="bg-slate-900 px-8 py-4 flex justify-between items-center text-white">
            <span className="text-sm font-bold opacity-60 uppercase tracking-widest">Assessment</span>
            <span className="text-sm font-bold">Question {currentIndex + 1} / {questions.length}</span>
          </div>

          <div className="p-10">
            <h3 className="text-2xl font-bold text-slate-800 mb-8 leading-tight">{currentQ.question}</h3>
            
            <div className="grid grid-cols-1 gap-4 mb-8">
              {currentQ.options.map((opt, idx) => {
                let bgColor = 'bg-slate-50 hover:bg-slate-100 border-transparent';
                let icon = null;

                if (selectedOption !== null) {
                  if (idx === currentQ.correctAnswer) {
                    bgColor = 'bg-green-50 border-green-200 text-green-800 ring-1 ring-green-500';
                    icon = <CheckCircle2 className="text-green-500" size={20} />;
                  } else if (idx === selectedOption) {
                    bgColor = 'bg-red-50 border-red-200 text-red-800 ring-1 ring-red-500';
                    icon = <XCircle className="text-red-500" size={20} />;
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelect(idx)}
                    disabled={selectedOption !== null}
                    className={`flex items-center justify-between p-5 rounded-2xl border-2 text-left transition-all duration-200 font-medium ${bgColor}`}
                  >
                    <span>{opt}</span>
                    {icon}
                  </button>
                );
              })}
            </div>

            {showExplanation && (
              <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 mb-8 animate-in fade-in slide-in-from-top-2">
                <p className="text-blue-800 text-sm font-medium mb-1 flex items-center gap-2">
                  <BrainCircuit size={16} /> Tutor Insight:
                </p>
                <p className="text-blue-600 text-sm leading-relaxed">{currentQ.explanation}</p>
              </div>
            )}

            {selectedOption !== null && (
              <button
                onClick={handleNext}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all shadow-lg"
              >
                {currentIndex === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Quiz;
