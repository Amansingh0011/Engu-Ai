
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { 
  Send, 
  Mic, 
  MicOff, 
  ChevronLeft, 
  Loader2, 
  Users, 
  Monitor, 
  Sparkles,
  Award,
  Volume2,
  Play,
  MessageCircle
} from 'lucide-react';
import { ChatMessage, CourseModule, Lesson } from '../types';

interface OnlineClassProps {
  course: Lesson;
  module: CourseModule;
  onBack: () => void;
  onUpdateXP: (xp: number) => void;
}

const OnlineClass: React.FC<OnlineClassProps> = ({ course, module, onBack, onUpdateXP }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [currentScore, setCurrentScore] = useState(0);
  const [blackboardText, setBlackboardText] = useState("");
  const [isClassStarted, setIsClassStarted] = useState(false);
  const [showInput, setShowInput] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const blackboardScrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const currentSourceRef = useRef<AudioBufferSourceNode | null>(null);

  const TEACHER_INSTRUCTION = `You are "Engu Teacher", a professional English educator for Indian students.
  
  MANDATORY INTRO FLOW:
  1. Your very first message MUST start exactly with: "Hi there, I am your English teacher." 
  2. Then introduce yourself as Engu Teacher.
  3. Then ask for the learner's name.
  4. Wait for the name. Once you have it, greet them personally.
  
  TEACHING STYLE:
  - You are teaching the module: "${module.title}" in "${course.title}".
  - Start from absolute BASICS (Level 0). Use simple words.
  - Mix English with supportive Hinglish.
  - Prefix what you want to write on the blackboard with "[BOARD: text]". 
  - Every time you speak, write the core sentence or key lesson on the blackboard.
  - IMPORTANT: You MUST end your turn with a question to the student so they know when to reply.
  - Award XP points (+5 or +10) for replies.
  
  ENVIRONMENT:
  - This is a formal yet friendly Virtual Classroom.
  - Keep responses concise (2-4 sentences max).`;

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        handleSend(transcript);
      };
      recognitionRef.current.onend = () => setIsListening(false);
    }
  }, []);

  useEffect(() => {
    if (blackboardScrollRef.current) {
      blackboardScrollRef.current.scrollTop = blackboardScrollRef.current.scrollHeight;
    }
  }, [blackboardText]);

  const decodeBase64 = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const playTTS = async (text: string) => {
    if (currentSourceRef.current) {
      try { currentSourceRef.current.stop(); } catch(e) {}
    }

    const cleanText = text.replace(/\[BOARD:.*?\]/g, '').trim();

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: cleanText }] }],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        if (!audioContextRef.current) audioContextRef.current = new AudioContext({ sampleRate: 24000 });
        const buffer = await decodeAudioData(decodeBase64(base64Audio), audioContextRef.current, 24000, 1);
        const source = audioContextRef.current.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContextRef.current.destination);
        source.onended = () => {
          if (text.includes('?')) setShowInput(true);
        };
        source.start();
        currentSourceRef.current = source;
      } else {
        throw new Error("No audio data returned");
      }
    } catch (e: any) {
      console.warn("Gemini TTS failed, falling back to browser SpeechSynthesis", e);
      // Fallback to browser's native speech synthesis
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = 'en-IN';
      utterance.rate = 0.9;
      utterance.onend = () => {
        if (text.includes('?')) setShowInput(true);
      };
      window.speechSynthesis.speak(utterance);
      
      if (text.includes('?') && !window.speechSynthesis.speaking) {
         setShowInput(true);
      }
    }
  };

  const startClass = async () => {
    setIsClassStarted(true);
    setIsTyping(true);
    setShowInput(false);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ role: 'user', parts: [{ text: "Class is starting now. Please follow your mandatory intro flow." }] }],
        config: { systemInstruction: TEACHER_INSTRUCTION },
      });

      processResponse(response.text || "");
    } catch (e) {
      console.error(e);
      setIsTyping(false);
    }
  };

  const processResponse = (text: string) => {
    setIsTyping(false);
    const boardMatch = text.match(/\[BOARD: (.*?)\]/);
    if (boardMatch) {
      setBlackboardText(prev => prev + (prev ? "\n" : "") + boardMatch[1]);
    } else {
      const firstSentence = text.split(/[.!?]/)[0];
      if (firstSentence.length > 5) {
        setBlackboardText(prev => prev + (prev ? "\n" : "") + firstSentence);
      }
    }

    const xpMatch = text.match(/\+(\d+) XP/);
    if (xpMatch) {
      const added = parseInt(xpMatch[1]);
      setCurrentScore(s => s + added);
      onUpdateXP(added);
    }

    const cleanText = text.replace(/\[BOARD:.*?\]/g, '').trim();
    const aiMsg: ChatMessage = { role: 'model', text: cleanText, timestamp: new Date() };
    setMessages(prev => [...prev, aiMsg]);
    playTTS(cleanText);
  };

  const handleSend = async (customInput?: string) => {
    const textToSend = customInput || input;
    if (!textToSend.trim() || isTyping) return;

    const userMsg: ChatMessage = { role: 'user', text: textToSend, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    setShowInput(false);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          ...messages.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
          { role: 'user', parts: [{ text: textToSend }] }
        ],
        config: { systemInstruction: TEACHER_INSTRUCTION },
      });

      processResponse(response.text || "");
    } catch (e) {
      console.error(e);
      setIsTyping(false);
    }
  };

  const toggleMic = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  const onFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSend();
  };

  if (!isClassStarted) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-8 animate-in fade-in duration-500">
        <div className="relative group">
           <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-indigo-600 rounded-full blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
           <div className="relative bg-white p-8 rounded-full shadow-2xl">
             <Monitor size={64} className="text-emerald-600" />
           </div>
        </div>
        <div className="text-center space-y-2 px-6">
          <h2 className="text-3xl font-black text-slate-800 tracking-tight uppercase">Enter Virtual Classroom</h2>
          <p className="text-slate-500 font-medium">{module.title}</p>
        </div>
        <button 
          onClick={startClass}
          className="px-12 py-5 bg-emerald-600 text-white rounded-2xl font-black text-xl hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-100 flex items-center gap-4 active:scale-95"
        >
          <Play size={24} fill="currentColor" /> Let's Start
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto h-[calc(100vh-100px)] flex flex-col gap-4 animate-in fade-in duration-700 pb-4 overflow-hidden">
      
      {/* Header Info */}
      <div className="flex items-center justify-between px-4 shrink-0">
         <button onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-red-500 font-bold text-xs uppercase transition-colors" aria-label="Exit Classroom">
           <ChevronLeft size={16} /> Exit
         </button>
         <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100">
              <Users size={12} /> Live
            </div>
            <div className="flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100">
              <Award size={12} /> {currentScore} XP
            </div>
         </div>
      </div>

      {/* ENLARGED DIGITAL BLACKBOARD - Covers half screen */}
      <div className="relative h-[55vh] md:h-[60vh] bg-slate-900 rounded-[2.5rem] md:rounded-[3rem] shadow-2xl border-[12px] md:border-[16px] border-slate-800 overflow-hidden flex flex-col p-6 md:p-12 group shrink-0">
        <div className="relative z-10 flex flex-col h-full">
          <div className="flex items-center justify-between mb-6 md:mb-10">
            <h3 className="text-emerald-400/40 font-black uppercase tracking-[0.4em] text-[10px] md:text-[11px] flex items-center gap-3">
              <div className="w-2 md:w-2.5 h-2 md:h-2.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_15px_rgba(16,185,129,0.6)]"></div>
              Blackboard
            </h3>
            {isTyping && (
               <div className="flex items-center gap-2 text-white/30 text-[9px] md:text-[10px] font-black uppercase tracking-widest">
                 <Loader2 size={12} className="animate-spin" /> Writing...
               </div>
            )}
          </div>
          
          <div 
            ref={blackboardScrollRef}
            className="flex-grow font-serif italic text-white/95 text-xl md:text-4xl leading-relaxed whitespace-pre-wrap select-none chalkboard-style overflow-y-auto custom-scrollbar pr-2 md:pr-6"
            tabIndex={0}
            aria-label="Teacher blackboard content"
          >
            {blackboardText || "Teacher is entering the room..."}
            {isTyping && <span className="inline-block w-4 h-8 md:h-10 bg-emerald-500/30 ml-2 animate-pulse rounded-sm"></span>}
          </div>

          {/* Subtitles (Last response for accessibility) */}
          {messages.length > 0 && messages[messages.length-1].role === 'model' && (
            <div className="mt-4 pt-4 border-t border-white/5 bg-black/40 -mx-6 md:-mx-12 px-6 md:px-12 py-3 md:py-6">
               <div className="flex items-start gap-3">
                  <div className="w-6 h-6 md:w-8 md:h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center shrink-0">
                    <Volume2 size={14} className="text-indigo-400" />
                  </div>
                  <p className="text-white/60 text-[11px] md:text-sm italic font-medium leading-relaxed line-clamp-2 md:line-clamp-none">
                    "{messages[messages.length-1].text}"
                  </p>
               </div>
            </div>
          )}
        </div>
        
        <div className="absolute inset-0 pointer-events-none opacity-[0.04] bg-[url('https://www.transparenttextures.com/patterns/black-chalk.png')]"></div>
      </div>

      {/* INTERACTIVE REPLY AREA - Directly under board */}
      <div className={`flex-grow flex flex-col justify-end px-2 md:px-0 transition-all duration-500 ${showInput ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0 pointer-events-none'}`}>
        <div className="bg-white rounded-[2rem] md:rounded-[2.5rem] shadow-2xl border border-slate-100 p-4 md:p-6 flex items-center gap-2 md:gap-4 mb-2">
          <button 
            onClick={toggleMic}
            aria-label={isListening ? "Stop voice input" : "Start voice input"}
            className={`p-4 md:p-5 rounded-2xl transition-all duration-300 relative shrink-0 ${isListening ? 'bg-red-500 text-white ring-4 ring-red-500/20 shadow-lg' : 'bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-indigo-600'}`}
          >
            {isListening ? <MicOff size={22} className="animate-pulse" /> : <Mic size={22} />}
          </button>

          <form onSubmit={onFormSubmit} className="relative flex-grow flex items-center gap-2">
            <input 
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={isListening ? "Listening..." : "Your answer..."}
              aria-label="Your response to the teacher"
              className="w-full bg-slate-50 border-none rounded-[1.2rem] md:rounded-[1.5rem] px-5 md:px-8 py-4 md:py-5 text-sm font-medium text-slate-800 placeholder-slate-400 focus:ring-2 focus:ring-emerald-500 outline-none transition-all shadow-inner"
            />
            <button 
              type="submit"
              disabled={!input.trim() || isTyping}
              aria-label="Send response"
              className="shrink-0 p-2.5 md:p-3 bg-emerald-600 text-white rounded-xl disabled:opacity-30 transition-all hover:bg-emerald-700 shadow-lg shadow-emerald-100 active:scale-95 flex items-center justify-center"
            >
              <Send size={18} />
            </button>
          </form>
        </div>
        <p className="text-[8px] md:text-[9px] text-center text-slate-400 font-black uppercase tracking-[0.3em]">Engu Virtual Teacher Active</p>
      </div>

      <style>{`
        .chalkboard-style {
          text-shadow: 2px 2px 3px rgba(0,0,0,0.4), 0 0 15px rgba(255,255,255,0.05);
          letter-spacing: -0.01em;
          filter: contrast(1.1);
          font-family: 'Times New Roman', serif;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(16, 185, 129, 0.2);
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
};

export default OnlineClass;
