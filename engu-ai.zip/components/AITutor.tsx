
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Mic, MicOff, Volume2, Loader2, Languages, Book, AlertCircle } from 'lucide-react';
import { getAITutorResponse } from '../services/geminiService';
import { ChatMessage, Lesson } from '../types';

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

interface AITutorProps {
  initialContext?: Lesson | null;
}

const AITutor: React.FC<AITutorProps> = ({ initialContext }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [sttError, setSttError] = useState<string | null>(null);
  const [langPreference, setLangPreference] = useState<'hinglish' | 'hindi' | 'english'>('hinglish');
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Sync recognition language with preference
  useEffect(() => {
    if (recognitionRef.current) {
      const langMap = {
        'hinglish': 'hi-IN', // hi-IN often handles mixed English well in STT
        'hindi': 'hi-IN',
        'english': 'en-US'
      };
      recognitionRef.current.lang = langMap[langPreference];
    }
  }, [langPreference]);

  useEffect(() => {
    const greeting = initialContext 
      ? `Hi! I’m Engu AI — your pocket-sized guide to smarter English speaking. 🚀

I see you're starting **"${initialContext.title}"**. Bahut badhiya choice hai!

**Aap yahan se shuru kar sakte hain:**
1. Is course ke specific modules ke baare mein poocho.
2. Is topic se related koi real-life scenario practice karein.
3. Ya fir mujhse koi concept explain karne ko kahein.

Main ready hoon, chaliye ${initialContext.category} master karte hain!`
      : `Hi! I’m Engu AI — your pocket-sized guide to smarter English speaking. 👋

Namaste! Aaj hum kya practice karenge? Main aapko English sikhane mein help karunga.

🚀 **Kuch bindaas suggestions aapke liye:**
- **Join a Course:** "Public Speaking Mastery" join karke stage fright dur karein.
- **Roleplay Scenario:** Chalo practice karte hain **'Ordering food in a restaurant'**.
- **Career Prep:** Interview prep ya email writing seekhein.

Aap batayiye, what's on your mind today?`;
    
    setMessages([{ 
      role: 'model', 
      text: greeting, 
      timestamp: new Date() 
    }]);
  }, [initialContext]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true; // Enable interim results for better UX

      recognitionRef.current.onstart = () => {
        setIsListening(true);
        setSttError(null);
      };

      recognitionRef.current.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          setInput(prev => prev + (prev ? ' ' : '') + finalTranscript);
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        if (event.error === 'not-allowed') {
          setSttError('Mic access denied. Please allow mic permissions.');
        } else {
          setSttError('Could not hear you. Try again?');
        }
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    } else {
      setSttError('Voice input is not supported in this browser.');
    }
  }, []);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      setSttError(null);
      try {
        recognitionRef.current?.start();
      } catch (error) {
        console.error('Failed to start recognition:', error);
      }
    }
  };

  const speakMessage = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    // Rough language detection for better TTS voice selection
    if (langPreference === 'hindi' || (langPreference === 'hinglish' && /[\u0900-\u097F]/.test(text))) {
      utterance.lang = 'hi-IN';
    } else {
      utterance.lang = 'en-IN';
    }
    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    if (isListening) {
      recognitionRef.current?.stop();
    }

    const userMsg: ChatMessage = { role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    const contextualInput = initialContext 
      ? `[Learning context: ${initialContext.title}] ${input}`
      : input;

    const aiResponse = await getAITutorResponse(messages, contextualInput, langPreference);
    
    setIsTyping(false);
    setMessages(prev => [...prev, { role: 'model', text: aiResponse, timestamp: new Date() }]);
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-180px)] flex flex-col bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100 animate-in fade-in duration-500">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 px-8 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center relative">
            <Sparkles className="text-indigo-600" size={24} />
            <div className={`absolute bottom-0 right-0 w-3 h-3 border-2 border-white rounded-full ${isListening ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`}></div>
          </div>
          <div>
            <h2 className="font-bold text-slate-800">
              {initialContext ? `Tutor: ${initialContext.title}` : 'Engu AI Tutor'}
            </h2>
            <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
              {initialContext && <Book size={10} className="text-indigo-400" />}
              <span>{initialContext ? 'Course-Specific Learning' : 'General Practice'}</span>
            </div>
          </div>
        </div>
        
        <div className="flex bg-slate-100 p-1 rounded-xl">
          {[
            { id: 'english', label: 'English' },
            { id: 'hinglish', label: 'Hinglish' },
            { id: 'hindi', label: 'Hindi' }
          ].map((lang) => (
            <button
              key={lang.id}
              onClick={() => setLangPreference(lang.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                langPreference === lang.id 
                  ? 'bg-white text-indigo-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {lang.label}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-grow p-8 overflow-y-auto space-y-6 bg-slate-50/30"
      >
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`group relative max-w-[80%] px-6 py-4 rounded-2xl ${
              m.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg shadow-indigo-100' 
                : 'bg-white text-slate-800 shadow-sm border border-slate-100 rounded-tl-none'
            }`}>
              <div className="text-sm leading-relaxed whitespace-pre-wrap prose prose-sm max-w-none prose-slate">
                {m.text.split('\n').map((line, lineIdx) => (
                  <p key={lineIdx} className={line.trim().startsWith('-') || line.trim().startsWith('1.') ? 'ml-4' : ''}>
                    {line.split('**').map((part, partIdx) => 
                      partIdx % 2 === 1 ? <strong key={partIdx}>{part}</strong> : part
                    )}
                  </p>
                ))}
              </div>
              <div className="flex items-center justify-between mt-2 gap-4">
                <p className={`text-[10px] opacity-60 ${m.role === 'user' ? 'text-right flex-grow' : ''}`}>
                  {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
                {m.role === 'model' && (
                  <button 
                    onClick={() => speakMessage(m.text)}
                    className="p-1 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-indigo-600"
                    title="Read aloud"
                  >
                    <Volume2 size={12} />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white px-6 py-4 rounded-2xl rounded-tl-none shadow-sm border border-slate-100">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-slate-200 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-slate-200 rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-slate-200 rounded-full animate-bounce delay-200"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-slate-100">
        {sttError && (
          <div className="mb-4 flex items-center gap-2 text-xs text-red-500 bg-red-50 p-2 rounded-lg animate-in slide-in-from-bottom-2">
            <AlertCircle size={14} />
            {sttError}
          </div>
        )}
        
        <div className="relative flex items-center gap-3">
          <button 
            onClick={toggleListening}
            className={`p-3 rounded-xl transition-all duration-300 relative group ${
              isListening 
                ? 'bg-red-50 text-red-600 ring-2 ring-red-500 ring-offset-2' 
                : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
            }`}
            title={isListening ? "Stop listening" : "Start voice input"}
          >
            {isListening ? (
              <MicOff size={20} className="animate-pulse" />
            ) : (
              <Mic size={20} />
            )}
            {isListening && (
              <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] py-1 px-2 rounded whitespace-nowrap">
                Listening... Speak now
              </span>
            )}
          </button>
          
          <div className="relative flex-grow">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder={isListening ? "Listening... Bolo" : "Ask me anything..."}
              className={`w-full bg-slate-50 border-none rounded-2xl px-6 py-4 text-slate-800 placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 outline-none transition-all ${
                isListening ? 'ring-2 ring-red-100 animate-pulse' : ''
              }`}
            />
          </div>

          <button 
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="p-4 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-100"
          >
            {isTyping ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
          </button>
        </div>
        
        <div className="flex justify-center mt-4">
           <p className="text-[10px] text-slate-400 flex items-center gap-1">
             <Mic size={10} /> <span>Try saying: "Chalo 'Ordering Food' scenario practice karte hain"</span>
           </p>
        </div>
      </div>
    </div>
  );
};

export default AITutor;
