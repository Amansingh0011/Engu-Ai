
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, Type } from "@google/genai";
import { 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  Pause, 
  Volume2, 
  Sparkles, 
  Loader2, 
  Mic, 
  MicOff, 
  Send, 
  MessageSquare,
  Image as ImageIcon
} from 'lucide-react';
import { CourseModule, Lesson, ChatMessage } from '../types';

interface Slide {
  title: string;
  bullets: string[];
  hinglishScript: string;
  question: string;
  imagePrompt: string;
}

interface SlideLessonProps {
  course: Lesson;
  module: CourseModule;
  onBack: () => void;
}

export default function SlideLesson({ course, module, onBack }: SlideLessonProps) {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioLoading, setAudioLoading] = useState(false);
  const [slideImages, setSlideImages] = useState<Record<number, string>>({});
  const [imageLoading, setImageLoading] = useState<Record<number, boolean>>({});
  
  // Interaction State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isAILoading, setIsAILoading] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const currentSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const recognitionRef = useRef<any>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const decodeBase64 = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const generateSlides = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate a 4-slide interactive lesson for: "${module.title}" in course "${course.title}". 
        For each slide:
        1. title (short)
        2. bullets (2 key points)
        3. hinglishScript (A teacher-like explanation in Hinglish)
        4. question (A question to ask the learner at the end of this slide)
        5. imagePrompt (A detailed prompt for generating a relevant educational illustration for this slide).
        
        Return ONLY JSON format.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                bullets: { type: Type.ARRAY, items: { type: Type.STRING } },
                hinglishScript: { type: Type.STRING },
                question: { type: Type.STRING },
                imagePrompt: { type: Type.STRING }
              },
              required: ["title", "bullets", "hinglishScript", "question", "imagePrompt"]
            }
          }
        }
      });
      const data = JSON.parse(response.text);
      if (data && data.length > 0) {
        setSlides(data);
        generateSlideImage(0, data[0].imagePrompt);
      }
      setLoading(false);
    } catch (e) {
      console.error("Slide Generation Error:", e);
      setLoading(false);
    }
  };

  const generateSlideImage = async (index: number, prompt: string) => {
    if (slideImages[index] || imageLoading[index]) return;
    
    setImageLoading(prev => ({ ...prev, [index]: true }));
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [{ parts: [{ text: `Educational 3D illustration, clean modern style, high quality, flat colors: ${prompt}` }] }],
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          setSlideImages(prev => ({ ...prev, [index]: imageUrl }));
          break;
        }
      }
    } catch (e) {
      console.error("Image generation failed", e);
    } finally {
      setImageLoading(prev => ({ ...prev, [index]: false }));
    }
  };

  const playTeacherAudio = async (text: string) => {
    if (!text) return;
    if (currentSourceRef.current) currentSourceRef.current.stop();
    setAudioLoading(true);
    setIsPlaying(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Friendly teacher: ${text}` }] }],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: { 
            voiceConfig: { 
              prebuiltVoiceConfig: { voiceName: 'Kore' } 
            } 
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        if (!audioContextRef.current) audioContextRef.current = new AudioContext({ sampleRate: 24000 });
        const buffer = await decodeAudioData(decodeBase64(base64Audio), audioContextRef.current, 24000, 1);
        const source = audioContextRef.current.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContextRef.current.destination);
        source.onended = () => setIsPlaying(false);
        source.start();
        currentSourceRef.current = source;
      } else {
        throw new Error("No audio data");
      }
    } catch (e) {
      console.warn("Gemini TTS Quota exceeded or failed, using browser speech synthesis", e);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-IN';
      utterance.rate = 0.9;
      utterance.onend = () => setIsPlaying(false);
      window.speechSynthesis.speak(utterance);
      
      if (!window.speechSynthesis.speaking) setIsPlaying(false);
    } finally {
      setAudioLoading(false);
    }
  };

  const handleAISend = async (text: string) => {
    if (!text.trim() || !slides[currentIndex]) return;
    
    const userMsg: ChatMessage = { role: 'user', text, timestamp: new Date() };
    setChatMessages(prev => [...prev, userMsg]);
    setUserInput('');
    setIsAILoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const currentSlide = slides[currentIndex];
      const prompt = `Context: Slide Lesson on "${currentSlide.title}". 
      Teacher just explained: "${currentSlide.hinglishScript}" and asked: "${currentSlide.question}".
      User said: "${text}".
      Respond as a supportive Hinglish teacher. Acknowledge their answer and give a short 1-2 sentence feedback.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ parts: [{ text: prompt }] }],
      });

      const aiText = response.text || "Very good! Let's continue.";
      setChatMessages(prev => [...prev, { role: 'model', text: aiText, timestamp: new Date() }]);
      playTeacherAudio(aiText);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAILoading(false);
    }
  };

  useEffect(() => {
    generateSlides();
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setUserInput(transcript);
        handleAISend(transcript);
      };
      recognitionRef.current.onend = () => setIsListening(false);
    }
    return () => {
      if (currentSourceRef.current) currentSourceRef.current.stop();
      if (audioContextRef.current) audioContextRef.current.close();
      window.speechSynthesis.cancel();
    };
  }, []);

  const toggleMic = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      setChatMessages([]);
      setIsPlaying(false);
      window.speechSynthesis.cancel();
      if (slides[nextIdx]) {
        generateSlideImage(nextIdx, slides[nextIdx].imagePrompt);
      }
    }
  };

  if (loading || slides.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
        <Loader2 className="text-indigo-600 animate-spin" size={48} />
        <p className="text-slate-500 font-medium">Building your interactive AI classroom...</p>
      </div>
    );
  }

  const currentSlide = slides[currentIndex];

  return (
    <div className="max-w-6xl mx-auto space-y-4 animate-in fade-in zoom-in-95 duration-500 pb-10">
      <div className="flex items-center justify-between px-2">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 font-bold text-sm">
          <ChevronLeft size={18} /> Exit Class
        </button>
        <div className="flex items-center gap-4">
           <div className="h-1.5 w-40 bg-slate-200 rounded-full overflow-hidden">
             <div 
               className="h-full bg-indigo-600 transition-all duration-700" 
               style={{ width: `${((currentIndex + 1) / slides.length) * 100}%` }}
             ></div>
           </div>
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{currentIndex + 1} / {slides.length}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Content Area */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-slate-100 min-h-[500px] flex flex-col">
            <div className="flex justify-between items-start mb-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest">
                  <Sparkles size={12} /> Interactive Teacher
                </div>
                <h1 className="text-3xl font-extrabold text-slate-800">{currentSlide?.title}</h1>
              </div>
              <button 
                onClick={() => playTeacherAudio(`${currentSlide?.hinglishScript} ${currentSlide?.question}`)}
                className="p-4 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all active:scale-95"
                title="Play Lesson Audio"
              >
                {audioLoading ? <Loader2 size={24} className="animate-spin" /> : isPlaying ? <Pause size={24} /> : <Play size={24} />}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 flex-grow">
              <div className="space-y-6">
                <ul className="space-y-4">
                  {currentSlide?.bullets.map((bullet, i) => (
                    <li key={i} className="flex items-start gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 text-slate-700 text-sm leading-relaxed font-medium">
                      <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1.5 shrink-0"></div>
                      {bullet}
                    </li>
                  ))}
                </ul>
                <div className="p-6 bg-indigo-50/50 rounded-3xl border border-indigo-100/50">
                  <p className="text-xs font-black text-indigo-600 uppercase tracking-widest mb-2 flex items-center gap-2">
                    <MessageSquare size={14} /> Teacher's Question
                  </p>
                  <p className="text-indigo-900 font-bold leading-relaxed italic">
                    "{currentSlide?.question}"
                  </p>
                </div>
              </div>

              <div className="relative group">
                <div className="aspect-square bg-slate-100 rounded-3xl overflow-hidden flex items-center justify-center border-2 border-slate-50 shadow-inner">
                  {imageLoading[currentIndex] ? (
                    <div className="text-center space-y-3">
                      <Loader2 className="animate-spin text-indigo-400 mx-auto" size={32} />
                      <p className="text-[10px] text-slate-400 font-bold uppercase">Generating Visuals...</p>
                    </div>
                  ) : slideImages[currentIndex] ? (
                    <img src={slideImages[currentIndex]} alt="Slide Visual" className="w-full h-full object-cover animate-in fade-in duration-1000" />
                  ) : (
                    <div className="text-center opacity-30">
                      <ImageIcon size={48} className="mx-auto mb-2" />
                      <p className="text-[10px] font-bold">Visual Placeholder</p>
                    </div>
                  )}
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/10 to-transparent rounded-3xl"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Interaction Side Panel */}
        <div className="lg:col-span-4 bg-slate-900 rounded-[2rem] flex flex-col shadow-2xl overflow-hidden min-h-[500px]">
          <div className="p-6 border-b border-white/5 bg-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white">
                <MessageSquare size={20} />
              </div>
              <div>
                <p className="text-xs font-black text-white uppercase tracking-widest">Chat & Voice</p>
                <p className="text-[10px] text-indigo-400 font-bold">Reply to continue</p>
              </div>
            </div>
            {isPlaying && (
               <div className="flex items-end gap-1 h-3">
                 {[1,2,3].map(i => <div key={i} className="w-1 bg-indigo-500 rounded-full animate-pulse" style={{height: `${40+Math.random()*60}%`, animationDelay: `${i*0.1}s`}}></div>)}
               </div>
            )}
          </div>

          <div className="flex-grow p-6 overflow-y-auto space-y-4 bg-black/20 custom-scrollbar">
            {chatMessages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center text-indigo-400">
                  <Volume2 size={32} className="animate-pulse" />
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Teacher is waiting for your reply. You can answer using <span className="text-white font-bold">Voice</span> or <span className="text-white font-bold">Text</span>.
                </p>
              </div>
            )}
            {chatMessages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-4 py-3 rounded-2xl text-xs leading-relaxed ${
                  m.role === 'user' 
                    ? 'bg-indigo-600 text-white rounded-tr-none' 
                    : 'bg-white/10 text-slate-200 border border-white/5 rounded-tl-none'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isAILoading && (
               <div className="flex justify-start">
                 <div className="bg-white/5 px-4 py-3 rounded-2xl rounded-tl-none border border-white/5">
                    <div className="flex gap-1.5">
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce delay-75"></div>
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce delay-150"></div>
                    </div>
                 </div>
               </div>
            )}
            <div ref={chatEndRef} />
          </div>

          <div className="p-4 bg-white/5 border-t border-white/5 space-y-3">
            <div className="flex items-center gap-2">
              <button 
                onClick={toggleMic}
                className={`p-4 rounded-2xl transition-all duration-300 relative ${isListening ? 'bg-red-500 text-white ring-4 ring-red-500/20' : 'bg-white/10 text-slate-400 hover:text-white hover:bg-white/20'}`}
              >
                {isListening ? <MicOff size={20} className="animate-pulse" /> : <Mic size={20} />}
              </button>
              <div className="relative flex-grow">
                <input 
                  type="text" 
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAISend(userInput)}
                  placeholder={isListening ? "Listening..." : "Type your answer..."}
                  className="w-full bg-white/10 border-none rounded-2xl px-5 py-4 text-white text-xs placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <button 
                  onClick={() => handleAISend(userInput)}
                  disabled={!userInput.trim() || isAILoading}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-indigo-600 text-white rounded-xl disabled:opacity-30 disabled:grayscale transition-all"
                >
                  <Send size={16} />
                </button>
              </div>
            </div>
            <p className="text-[9px] text-center text-slate-500 font-bold uppercase tracking-tighter">Voice & Text enabled interaction</p>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center pt-2">
        <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-widest">
           <Volume2 size={12} className="text-indigo-400" /> Lesson Path: {module.title}
        </div>
        <button 
          onClick={handleNext}
          disabled={currentIndex === slides.length - 1}
          className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 disabled:opacity-20 disabled:grayscale transition-all flex items-center gap-3 shadow-xl shadow-slate-200"
        >
          Next Slide <ChevronRight size={18} />
        </button>
      </div>
    </div>
  );
}
