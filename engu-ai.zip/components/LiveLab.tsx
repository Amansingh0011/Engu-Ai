
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Mic, MicOff, PhoneOff, Sparkles, Volume2, Waves, AlertCircle, Key } from 'lucide-react';

export default function LiveLab() {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState('Voice Lab: Speak in English, ask in Hindi');
  const [error, setError] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string[]>([]);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const isClosingRef = useRef(false);

  const decode = (base64: string) => {
    try {
      const binaryString = atob(base64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
      return bytes;
    } catch (e) {
      console.error("Decoding error:", e);
      return new Uint8Array(0);
    }
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const createBlob = (data: Float32Array) => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) int16[i] = data[i] * 32768;
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  };

  const handleKeySelection = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio) {
      await aistudio.openSelectKey();
      setError(null);
      setStatus('Key selected. Try starting the session again.');
    }
  };

  const closeContexts = async () => {
    const ctxA = audioContextRef.current;
    const ctxO = outputContextRef.current;
    audioContextRef.current = null;
    outputContextRef.current = null;

    if (ctxA && ctxA.state !== 'closed') {
      try { await ctxA.close(); } catch (e) {}
    }
    if (ctxO && ctxO.state !== 'closed') {
      try { await ctxO.close(); } catch (e) {}
    }
  };

  const stopSession = async () => {
    if (isClosingRef.current) return;
    isClosingRef.current = true;
    
    setIsActive(false);
    setStatus('Ready to practice?');
    
    const session = sessionRef.current;
    sessionRef.current = null;
    if (session) {
      try { session.close(); } catch (e) {}
    }

    await closeContexts();

    for (const s of sourcesRef.current) {
      try { s.stop(); } catch (e) {}
    }
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    isClosingRef.current = false;
  };

  const startSession = async () => {
    if (isActive || isClosingRef.current) return;
    
    setError(null);
    setIsActive(true);
    setStatus('Checking requirements...');

    try {
      const aistudio = (window as any).aistudio;
      if (aistudio && !(await aistudio.hasSelectedApiKey())) {
        setStatus('Please select a paid API key...');
        await aistudio.openSelectKey();
      }

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      await closeContexts();

      const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
      audioContextRef.current = new AudioContextClass({ sampleRate: 16000 });
      outputContextRef.current = new AudioContextClass({ sampleRate: 24000 });
      
      let stream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch (e: any) {
        throw new Error('Microphone access denied. Please allow mic permissions.');
      }

      setStatus('Connecting to AI Tutor...');
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus('Conversation Live');
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(s => {
                if (s) {
                  try { s.sendRealtimeInput({ media: pcmBlob }); } catch (err) {}
                }
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData && outputContextRef.current && outputContextRef.current.state !== 'closed') {
              const ctx = outputContextRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }
          },
          onerror: (e: any) => {
            console.error('Live API Error:', e);
            const msg = (e.message || e.toString()).toLowerCase();
            if (msg.includes('not implemented') || msg.includes('not supported')) {
              setError('Live feature is not supported in this project/region. Please ensure you are using a Paid API key and the Generative Language API is enabled.');
            } else if (msg.includes('network error') || msg.includes('403')) {
              setError('Connection failed. Billing might not be enabled on your project.');
            } else {
              setError('A connection error occurred. Please re-select your Paid API key.');
            }
            stopSession();
          },
          onclose: (e) => {
            if (!isClosingRef.current) stopSession();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { 
              prebuiltVoiceConfig: { voiceName: 'Zephyr' } 
            }
          },
          systemInstruction: 'You are a friendly bilingual English tutor for Indian students. Use Hinglish as your primary voice.'
        }
      });
      
      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      console.error('Start session failed:', err);
      setError(err.message || 'Failed to start the session.');
      setIsActive(false);
      await closeContexts();
    }
  };

  useEffect(() => {
    return () => { stopSession(); };
  }, []);

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-180px)] flex flex-col items-center justify-center space-y-8 animate-in zoom-in-95 duration-700">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-slate-800">Live Voice Lab 🎙️</h2>
        <p className={`${error ? 'text-red-500 font-medium px-4' : 'text-slate-500'}`}>{error || status}</p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-100 rounded-2xl p-6 flex flex-col items-center gap-4 text-red-700 text-sm max-w-md text-center shadow-sm mx-4">
          <div className="flex items-center gap-3">
            <AlertCircle size={28} className="shrink-0" />
            <p className="font-medium">Live API requires a Paid API Key. Arre, billing check karein?</p>
          </div>
          <button 
            onClick={handleKeySelection}
            className="w-full bg-red-600 text-white px-4 py-3 rounded-xl font-bold hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
          >
            <Key size={18} /> Re-select Paid API Key
          </button>
        </div>
      )}

      <div className={`relative w-64 h-64 rounded-full flex items-center justify-center transition-all duration-500 ${isActive ? 'bg-indigo-600 scale-110 shadow-2xl shadow-indigo-200' : 'bg-white border-2 border-dashed border-slate-200 shadow-sm'}`}>
        {isActive ? (
          <div className="flex items-end gap-1 h-12">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="w-2 bg-white/40 rounded-full animate-bounce" style={{ height: `${20 + Math.random() * 80}%`, animationDelay: `${i * 0.1}s` }}></div>
            ))}
          </div>
        ) : (
          <Mic className="text-slate-300" size={64} />
        )}
      </div>

      <div className="flex gap-4">
        {!isActive ? (
          <button 
            onClick={startSession}
            disabled={isClosingRef.current}
            className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center gap-3"
          >
            <Sparkles size={24} /> Start Voice Session
          </button>
        ) : (
          <button 
            onClick={stopSession}
            disabled={isClosingRef.current}
            className="px-8 py-4 bg-red-500 text-white rounded-2xl font-bold text-lg hover:bg-red-600 transition-all shadow-xl shadow-red-100 flex items-center gap-3"
          >
            <PhoneOff size={24} /> End Session
          </button>
        )}
      </div>
    </div>
  );
}
