
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { TrendingUp, Award, Zap, Clock } from 'lucide-react';
import { UserProgress } from '../types';

const data = [
  { name: 'Mon', minutes: 15 },
  { name: 'Tue', minutes: 45 },
  { name: 'Wed', minutes: 30 },
  { name: 'Thu', minutes: 60 },
  { name: 'Fri', minutes: 25 },
  { name: 'Sat', minutes: 50 },
  { name: 'Sun', minutes: 40 },
];

interface DashboardProps {
  progress: UserProgress;
}

const Dashboard: React.FC<DashboardProps> = ({ progress }) => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header>
        <h1 className="text-3xl font-bold text-slate-800">Welcome back, Alex! 👋</h1>
        <p className="text-slate-500 mt-1">You're in the top 5% of learners this week. Keep it up!</p>
      </header>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total XP', value: progress.xp.toLocaleString(), icon: <Zap className="text-yellow-500" />, bg: 'bg-yellow-50' },
          { label: 'Current Level', value: progress.level, icon: <TrendingUp className="text-blue-500" />, bg: 'bg-blue-50' },
          { label: 'Daily Streak', value: `${progress.streak} Days`, icon: <Clock className="text-orange-500" />, bg: 'bg-orange-50' },
          { label: 'Badges Earned', value: progress.badges.length, icon: <Award className="text-purple-500" />, bg: 'bg-purple-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
            <div className={`${stat.bg} p-3 rounded-xl`}>{stat.icon}</div>
            <div>
              <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
              <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Activity Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold text-slate-800">Learning Activity</h2>
            <select className="bg-slate-50 border-none rounded-lg text-sm px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="minutes" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Milestones / Recommended */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex flex-col">
          <h2 className="text-xl font-bold text-slate-800 mb-6">Upcoming Milestones</h2>
          <div className="space-y-6 flex-grow">
            {[
              { title: 'Level 5 Achiever', target: 'Reach 5000 XP', progress: 75, color: 'bg-indigo-600' },
              { title: 'Consistency King', target: '10 Day Streak', progress: 40, color: 'bg-orange-500' },
              { title: 'Business Pro', target: 'Finish 5 Business Modules', progress: 90, color: 'bg-emerald-500' },
            ].map((m, i) => (
              <div key={i}>
                <div className="flex justify-between text-sm mb-2">
                  <span className="font-bold text-slate-700">{m.title}</span>
                  <span className="text-slate-400">{m.progress}%</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full ${m.color}`} style={{ width: `${m.progress}%` }}></div>
                </div>
                <p className="text-xs text-slate-400 mt-1">{m.target}</p>
              </div>
            ))}
          </div>
          <button className="w-full mt-8 py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-colors">
            View All Achievements
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
