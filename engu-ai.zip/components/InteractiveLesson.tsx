
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Send, Sparkles, ChevronLeft, Volume2, Trophy, Brain, Target, MessageSquare } from 'lucide-react';
import { ChatMessage, CourseModule, Lesson } from '../types';

interface InteractiveLessonProps {
  course: Lesson;
  module: CourseModule;
  onBack: () => void;
  onUpdateXP: (xp: number) => void;
}

const InteractiveLesson: React.FC<InteractiveLessonProps> = ({ course, module, onBack, onUpdateXP }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [currentScore, setCurrentScore] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const systemInstruction = `You are conducting an interactive, Ai text-based lesson titled: "${module.title}" as part of the course "${course.title}".

General Rules:
- Use simple English suitable for beginners.
- Be supportive, encouraging, and conversational.
- Keep responses short (3–6 sentences).
- Ask the learner questions and wait for replies.
- Track and award score points during the lesson.

Scoring System:
- Answering reflection question -> +10 XP
- Completing breathing practice -> +10 XP
- Visualization response -> +10 XP
- Writing introduction activity -> +20 XP
- Extra effort or thoughtful answers -> Bonus +5 XP
- Maximum score for lesson = 50 XP

Score Handling:
- Start user score at 0 XP.
- After each completed activity, show updated score.
- ALWAYS use this exact format when displaying score: Current Score: [XX/50 XP]
- Encourage the learner after scoring.
- At lesson end, display total score and praise effort.

Lesson Flow for "Overcoming Stage Fright":
1. Introduction: Start by saying "Many people feel nervous before speaking in public — and that’s completely normal. Stage fright happens because your brain sees the situation as stressful. The good news is that you can learn to manage it. Let’s explore how." Then ask: "Have you ever felt nervous while speaking in front of others?" Wait for reply. Then award +10 XP.
2. Why it happens: Explain fight or flight.
3. Technique 1: Controlled Breathing. Guide them (4-4-4). Ask if they tried it. Award +10 XP.
4. Technique 2: Visualization. Ask them to describe their moment. Award +10 XP.
5. Practice: Self Introduction. Ask for 3 sentences. Award +20 XP.
6. Closing: Final Score and encouragement.

Keep track of the user's progress through these steps. DO NOT SKIP steps unless user is extremely advanced.`;

  useEffect(() => {
    // Initial greeting
    const introText = "Many people feel nervous before speaking in public — and that’s completely normal.\nStage fright happens because your brain sees the situation as stressful.\nThe good news is that you can learn to manage it.\nLet’s explore how.\n\nHave you ever felt nervous while speaking in front of others?";
    
    setMessages([{
      role: 'model',
      text: introText,
      timestamp: new Date()
    }]);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg: ChatMessage = { role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          ...messages.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
          { role: 'user', parts: [{ text: input }] }
        ],
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.7,
        },
      });

      const aiText = response.text || "I'm sorry, I missed that. Can you repeat?";
      
      // Attempt to parse score from AI text
      const scoreMatch = aiText.match(/Current Score: \[(\d+)\/50 XP\]/);
      if (scoreMatch) {
        const newScore = parseInt(scoreMatch[1]);
        if (newScore > currentScore) {
          const diff = newScore - currentScore;
          setCurrentScore(newScore);
          onUpdateXP(diff);
        }
      }

      setMessages(prev => [...prev, { role: 'model', text: aiText, timestamp: new Date() }]);
    } catch (error) {
      console.error("Lesson Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "Arre, something went wrong. Let's try again?", timestamp: new Date() }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-180px)] flex flex-col bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-500">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 hover:bg-slate-50 rounded-xl transition-colors">
            <ChevronLeft size={20} className="text-slate-500" />
          </button>
          <div>
            <h2 className="font-bold text-slate-800 text-sm md:text-base">{module.title}</h2>
            <p className="text-[10px] text-slate-400 font-medium">Interactive AI Workshop</p>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-indigo-50 px-4 py-2 rounded-2xl border border-indigo-100">
          <Trophy size={16} className="text-indigo-600" />
          <div className="text-right">
            <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest leading-none">Lesson Score</p>
            <p className="text-sm font-black text-indigo-600 leading-none mt-1">{currentScore}/50 XP</p>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-1 w-full bg-slate-100">
        <div 
          className="h-full bg-indigo-500 transition-all duration-1000" 
          style={{ width: `${(currentScore / 50) * 100}%` }}
        ></div>
      </div>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-grow p-6 overflow-y-auto space-y-6 bg-slate-50/20"
      >
        <div className="flex justify-center mb-8">
          <div className="bg-white px-6 py-3 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
            <Brain className="text-indigo-500" size={20} />
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Interactive Classroom</span>
          </div>
        </div>

        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] px-5 py-3.5 rounded-2xl ${
              m.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg shadow-indigo-100' 
                : 'bg-white text-slate-800 shadow-sm border border-slate-100 rounded-tl-none'
            }`}>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>
              <p className={`text-[9px] mt-2 opacity-50 ${m.role === 'user' ? 'text-right' : ''}`}>
                {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white px-5 py-3 rounded-2xl rounded-tl-none shadow-sm border border-slate-100">
              <div className="flex gap-1.5">
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-100"></div>
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-200"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-slate-100">
        <div className="relative flex items-center gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your response..."
            className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 text-sm text-slate-800 placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 outline-none transition-all shadow-inner"
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="p-4 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-100 shrink-0"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default InteractiveLesson;
