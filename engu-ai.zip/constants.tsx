
import React from 'react';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Users, 
  UserCircle,
  Mic2,
  GraduationCap,
  Headphones
} from 'lucide-react';
import { AppView, Lesson } from './types';

export const NAV_ITEMS = [
  { id: AppView.DASHBOARD, label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
  { id: AppView.COURSES, label: 'Courses', icon: <GraduationCap size={20} /> },
  { id: AppView.AI_TUTOR, label: 'AI Tutor', icon: <MessageSquare size={20} /> },
  { id: AppView.VOICE_TEACHER, label: 'Voice Teacher', icon: <Headphones size={20} /> },
  { id: AppView.LIVE_LAB, label: 'Voice Lab', icon: <Mic2 size={20} /> },
  { id: AppView.COMMUNITY, label: 'Community', icon: <Users size={20} /> },
  { id: AppView.PROFILE, label: 'Profile', icon: <UserCircle size={20} /> },
];

export const COURSE_LIST: Lesson[] = [
  { 
    id: 'c1', 
    title: 'Public Speaking Mastery', 
    description: 'Learn to deliver powerful presentations and speeches with confidence.', 
    category: 'Communication', 
    difficulty: 'Advanced', 
    duration: '4 hours',
    xpReward: 1200,
    isFree: true,
    modules: [
      { id: 'm1', title: 'Overcoming Stage Fright', duration: '45m', content: 'Focus on breathing techniques and psychological anchors to manage anxiety before stepping on stage.' },
      { id: 'm2', title: 'The Power of Body Language', duration: '1h', content: 'Master open gestures, eye contact, and purposeful movement to command the room.' },
      { id: 'm3', title: 'Storytelling Techniques', duration: '1.5h', content: 'Use the Hero’s Journey framework to make your technical presentations engaging and memorable.' }
    ]
  },
  { 
    id: 'c2', 
    title: 'Corporate Interview Prep', 
    description: 'A dedicated path for job seekers to crack HR and technical rounds in English.', 
    category: 'Professional', 
    difficulty: 'Intermediate', 
    duration: '5 hours',
    xpReward: 1000,
    isFree: true,
    modules: [
      { id: 'm1', title: 'Self-Introduction (The Pitch)', duration: '1h', content: 'Drafting and practicing a perfect 90-second introduction that highlights your USP.' },
      { id: 'm2', title: 'Answering Behavioral Questions', duration: '2h', content: 'Using the STAR (Situation, Task, Action, Result) method for complex questions.' }
    ]
  },
  { 
    id: 'c3', 
    title: 'IELTS Band 8.0 Crash Course', 
    description: 'Intensive training for Speaking and Writing modules of the IELTS exam.', 
    category: 'Academic', 
    difficulty: 'Advanced', 
    duration: '12 hours',
    xpReward: 3000,
    isFree: false,
    modules: [
      { id: 'm1', title: 'Speaking Part 2: Cue Cards', duration: '2h', content: 'Mastering the 2-minute monologue with high-level vocabulary and fluency.' }
    ]
  },
  { 
    id: 'c4', 
    title: 'Email Etiquette for Professionals', 
    description: 'Write better, faster, and more professional emails to clients and managers.', 
    category: 'Writing', 
    difficulty: 'Beginner', 
    duration: '3 hours',
    xpReward: 600,
    isFree: true,
    modules: [
      { id: 'm1', title: 'Formal vs Informal Tones', duration: '1h', content: 'Understanding when to use "Dear" vs "Hi" and the nuances of polite requests.' }
    ]
  }
];

export const BADGES = [
  { id: 'early_bird', name: 'Early Bird', icon: '🌅', description: 'Complete a lesson before 8 AM' },
  { id: 'streak_5', name: '5 Day Streak', icon: '🔥', description: 'Learned for 5 consecutive days' },
  { id: 'ai_expert', name: 'AI Partner', icon: '🤖', description: 'Engage in 10 AI Tutor conversations' },
  { id: 'quiz_master', name: 'Quiz Master', icon: '🎯', description: 'Score 100% on 3 quizzes' },
];
